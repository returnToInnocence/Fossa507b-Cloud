package com.zenq.cloud507b.po;

/**
 * <p>
 *
 * </p>
 *
 * @author chenxi
 * @since 2023-07-03
 */
public class MSG {
	String msg;
	
	public MSG(String msg) {
		super();
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	
	
}
