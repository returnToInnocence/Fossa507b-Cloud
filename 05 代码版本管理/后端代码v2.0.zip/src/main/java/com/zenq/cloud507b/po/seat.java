package com.zenq.cloud507b.po;

public class seat {
    private String seat_id;
    private String seat_status;
    private String seat_userhost;
    private String seat_userguest;

}
