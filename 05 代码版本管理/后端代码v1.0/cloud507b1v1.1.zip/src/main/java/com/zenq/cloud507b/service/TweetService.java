package com.zenq.cloud507b.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.zenq.cloud507b.mapper.TweetMapper;
import com.zenq.cloud507b.po.Tweet;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author chenxi
 * @since 2023-07-01
 */
@Service
public class TweetService{

}
