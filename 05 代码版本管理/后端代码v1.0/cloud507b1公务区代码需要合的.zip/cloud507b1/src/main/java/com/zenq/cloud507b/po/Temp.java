package com.zenq.cloud507b.po;

import lombok.Data;

@Data
public class Temp {
    private int temper;
    private int population;
}
