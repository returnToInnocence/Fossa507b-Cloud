package com.zenq.cloud507b.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author chenxi
 * @since 2023-07-01
 */
@Controller
@RequestMapping("/api/disscusion")
public class DisscusionController {

}
