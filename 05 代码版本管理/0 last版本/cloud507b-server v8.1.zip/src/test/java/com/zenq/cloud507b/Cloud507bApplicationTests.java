package com.zenq.cloud507b;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cloud507bApplicationTests {

    @Test
    void contextLoads() {
    }

}
