package com.zenq.cloud507b.po;

public class Doorqueue {
    private String userid;

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    @Override
    public String toString() {
        return "Doorqueue{" +
                "userid=" + userid +
                "}";
    }
}
