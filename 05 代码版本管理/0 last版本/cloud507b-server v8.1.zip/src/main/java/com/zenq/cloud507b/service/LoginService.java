package com.zenq.cloud507b.service;


public interface LoginService {
	String getpwdbyname(String name);
	String getUidbyname(String name);
	String getnamebyid(String id);
	String getpwdbyid(String id);
}
