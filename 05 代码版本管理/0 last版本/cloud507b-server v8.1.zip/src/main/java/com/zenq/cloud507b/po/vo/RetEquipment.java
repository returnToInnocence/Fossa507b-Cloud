package com.zenq.cloud507b.po.vo;

public class RetEquipment {
    public String userid;
    public String username;
    public String text;
    public String time;
    public String status;

}
