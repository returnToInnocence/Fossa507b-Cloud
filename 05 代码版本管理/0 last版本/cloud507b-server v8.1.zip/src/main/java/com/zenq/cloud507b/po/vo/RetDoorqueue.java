package com.zenq.cloud507b.po.vo;

public class RetDoorqueue {
    public String username;
    public String userid;

}
