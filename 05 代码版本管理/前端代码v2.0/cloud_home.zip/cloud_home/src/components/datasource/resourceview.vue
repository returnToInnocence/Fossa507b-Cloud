<template>
  <div class="container">
    <div class="box1">
      <div id="chart1" ref="myChart2" class="column"></div>
      <div class="box2">
        <el-button text  id="button3">
          座位资源详情
        </el-button>
      </div>
    </div>
    <div class="box1">
      <div id="chart2" class="column" ref="myChart1"></div>
      <div class="box2">
        <el-button text @click="dialogVisible = true" id="button1">
          吵闹程度投票
        </el-button>
        <el-dialog
          v-model="dialogVisible"
          title="请选择吵闹程度"
          width="30%"
          draggable
        >
          <el-select v-model="value" class="m-2" placeholder="请选择">
            <el-option
              v-for="item in options"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
          <template #footer>
            <span class="dialog-footer">
              <el-button @click="dialogVisible = false">取消</el-button>
              <el-button type="primary" @click="dialogVisible = false">
                确认
              </el-button>
            </span>
          </template>
        </el-dialog>
      </div>
    </div>
    <div class="box1">
      <div id="chart3" class="column" ref="myChart3"></div>
      <div class="box2">
        <el-button text @click="open()" id="button2">期望温度反馈</el-button>
      </div>
    </div>
  </div>
</template>

<script>
import * as echarts from "echarts";
import { ref } from "vue";
import { ElMessage, ElMessageBox } from "element-plus";
import { setBlockTracking } from "vue";
export default {
  data: () => ({
    dialogVisible: ref(false),
    //吵闹程度选择的配置，value和options
    value: ref(""),
    options: [
      {
        value: "1",
        label: "很吵",
      },
      {
        value: "2",
        label: "有点吵",
      },
      {
        value: "3",
        label: "正常",
      },
      {
        value: "4",
        label: "安静",
      },
    ],
  }),
  name: "datapic",
  mounted() {
    this.drawLine();
    this.drawZhu();
    this.drawLine1();
  },
  methods: {
    open() {
      console.log("heloowooo");
      ElMessageBox.prompt("请输入你期望的空调温度", "Tip", {
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        inputPattern: /^\d+$/,
        inputErrorMessage: "不是温度值",
      })
        .then(({ value }) => {
          ElMessage({
            type: "success",
            message: `你期望的温度为:${value}`,
          });
        })
        .catch(() => {
          ElMessage({
            type: "info",
            message: "取消输入",
          });
        });
    },
    //图1，柱状图
    drawZhu() {
      let myChart = echarts.init(this.$refs.myChart2);
      var option;
      option = {
        title: {
          text: "座位使用情况",
          left: "center", // 设置标题水平居中
          color: "black",
          textStyle: {
            color: "#333", // 设置标题颜色
            fontSize: 18, // 设置标题字号
            fontWeight: "bold", // 设置标题加粗
            fontFamily: "Arial, sans-serif", // 设置标题字体
          },
        },
        tooltip: {
          trigger: "axis",
          axisPointer: {
            type: "shadow",
          },
        },

        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: [
          {
            type: "category",
            data: [
              "2021-11",
              "2021-12",
              "2022-1",
              "2022-2",
              "2022-3",
              "2022-4",
              "2022-5",
              "2022-6",
              "2022-7",
              "2022-8",
              "2022-9",
              "2022-10",
            ],
          },
        ],
        yAxis: [
          {
            type: "value",
          },
        ],
        series: [
          {
            name: "食品",
            type: "bar",
            stack: "Ad",
            emphasis: {
              focus: "series",
            },
            data: [320, 332, 301, 334, 390, 330, 320, 301, 334, 390, 330, 320],
          },
          {
            name: "日用百货",
            type: "bar",
            stack: "Ad",
            emphasis: {
              focus: "series",
            },
            data: [120, 132, 101, 134, 90, 230, 210, 101, 134, 90, 230, 210],
          },
          {
            name: "果蔬",
            type: "bar",
            stack: "Ad",
            emphasis: {
              focus: "series",
            },
            data: [220, 182, 191, 234, 290, 330, 310, 191, 234, 290, 330, 310],
          },
        ],
      };
      option && myChart.setOption(option);
    },
    //图2，折线图
    drawLine() {
      let myChart = echarts.init(this.$refs.myChart1);
      var option;

      option = {
        title: {
          text: "吵闹程度",
          left:'center',
          textStyle: {
            color: "#333", // 设置标题颜色
            fontSize: 18, // 设置标题字号
            fontWeight: "bold", // 设置标题加粗
            fontFamily: "Arial, sans-serif", // 设置标题字体
          },
        },
        tooltip: {
          trigger: "axis",
        },

        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: [
            "2021-11",
            "2021-12",
            "2022-1",
            "2022-2",
            "2022-3",
            "2022-4",
            "2022-5",
            "2022-6",
            "2022-7",
            "2022-8",
            "2022-9",
            "2022-10",
          ],
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "蛋奶",
            type: "line",
            stack: "Total",
            data: [
              820, 932, 901, 934, 1290, 1330, 1320, 901, 934, 1290, 1330, 1320,
            ],
          },
        ],
      };

      option && myChart.setOption(option);
    },
    //图3，双折线
    drawLine1() {
      let myChart = echarts.init(this.$refs.myChart3);
      var option;

      option = {
        title: {
          text: "空调温度和希望空调温度",
          left:'center',
          textStyle: {
            color: "#333", // 设置标题颜色
            fontSize: 18, // 设置标题字号
            fontWeight: "bold", // 设置标题加粗
            fontFamily: "Arial, sans-serif", // 设置标题字体
          },
        },
        tooltip: {
          trigger: "axis",
        },
        grid: {
          left: "3%",
          right: "4%",
          bottom: "3%",
          containLabel: true,
        },
        xAxis: {
          type: "category",
          boundaryGap: false,
          data: [
            "2021-11",
            "2021-12",
            "2022-1",
            "2022-2",
            "2022-3",
            "2022-4",
            "2022-5",
            "2022-6",
            "2022-7",
            "2022-8",
            "2022-9",
            "2022-10",
          ],
        },
        yAxis: {
          type: "value",
        },
        series: [
          {
            name: "食品",
            type: "line",
            stack: "Total",
            data: [120, 132, 101, 134, 90, 230, 210, 101, 134, 90, 230, 210],
          },
          {
            name: "日用百货",
            type: "line",
            stack: "Total",
            data: [220, 182, 191, 234, 290, 330, 310, 191, 234, 290, 330, 310],
          },
        ],
      };

      option && myChart.setOption(option);
    },
  },
};
</script>

<style>
.container {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px; /* 可以根据需要调整列之间的间隔 */
}
.box1 {
  height: 450px;
  margin-top:3vh;
  /* background-color: blue; */
}
.column {
  /* background-color: #583636; */
  height: 350px;
}
.box2 {
  margin-top: 4vh;
  height: 60px;
  /* background-color: rgb(142, 33, 66); */
}
/* 温度按钮 */
#button2 {
  width: 100%;
  height: 100%;
 
}
/* 吵闹程度按钮 */
#button1,#button3 {
  width: 100%;
  height: 100%;
}
.m-2 {
  position: absolute;
  left: 10%;
  width: 80%;
}
</style>
