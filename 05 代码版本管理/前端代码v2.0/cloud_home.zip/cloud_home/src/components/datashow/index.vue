<script setup>

</script>

<template>
这是show index，是刚登录的展示页
</template>

<style scoped>

</style>